sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{commentsedit:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Commentsedit.js.map